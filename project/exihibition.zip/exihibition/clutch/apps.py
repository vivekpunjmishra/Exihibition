from django.apps import AppConfig


class ClutchConfig(AppConfig):
    name = 'clutch'
