from django.contrib import admin
from .models import Paintings

# Register your models here.
admin.site.register(Paintings)